const fs = require('fs');

const premXp = 10000;
const freeXp = 3000;
const premLimit = 100;
const freeLimit = 30;
const monthMs = 30 * 24 * 60 * 60 * 1000;

let handler = async (m, { conn, text, isPrems }) => {
    let users = global.db.data.users;
    let user = users[m.sender];
    let lastClaimTime = user.lastmonthly || 0;
    let currentTime = new Date().getTime();

    if (currentTime - lastClaimTime < monthMs) throw `📅 *Anda sudah klaim hadiah bulanan!*\n\n⏳ Klaim lagi dalam *${msToTime(monthMs - (currentTime - lastClaimTime))}*`;

    let xpReward = isPrems ? premXp : freeXp;
    let limitReward = isPrems ? premLimit : freeLimit;

    user.exp += xpReward;
    users[m.sender].limit += limitReward; // Penyesuaian struktur limit
    user.lastmonthly = currentTime;

    m.reply(`
🎁 *HADIAH BULANAN*
Terima kasih sudah tetap bersama kami!

📈 *XP*     : +${xpReward}
🔁 *Limit* : +${limitReward}

Klaim bisa dilakukan setiap 30 hari sekali.
`);
};

handler.help = ['monthly'];
handler.command = ['monthly'];
handler.tags = ['rpg'];
handler.rpg = true;

module.exports = handler;

function msToTime(duration) {
    var milliseconds = parseInt((duration % 1000) / 100),
        seconds = Math.floor((duration / 1000) % 60),
        minutes = Math.floor((duration / (1000 * 60)) % 60),
        hours = Math.floor((duration / (1000 * 60 * 60)) % 24),
        days = Math.floor(duration / (1000 * 60 * 60 * 24));

    return `${days} Hari ${hours} Jam ${minutes} Menit`;
}

//BY RGAN
//JANGAN HAPUS CREDITS!!