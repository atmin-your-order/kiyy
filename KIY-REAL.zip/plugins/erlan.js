

let handler = async (m, { conn, command }) => {
    global.anu = [
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`,
        `─────〔 *${command}* 〕─────
     "Admin mengendalikan, kebenaran mengikuti perintahnya."`,
        `─────〔 *${command}* 〕─────
     "salah paul"`,
        `─────〔 *${command}* 〕─────
     "paul salah"`,
        `─────〔 *${command}* 〕─────
     "paul bersalah"`,
        `─────〔 *${command}* 〕─────
     "ADMINNNNNNNNNNNNN"`,
        `─────〔 *${command}* 〕─────
     "admin hytam"`,
        `─────〔 *${command}* 〕─────
     "dimana ada kegelapan di situ ada cahaya"`,
        `─────〔 *${command}* 〕─────
     "Admin selalu benar, karena kebenaran adalah milik yang berkuasa."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin bicara, aturan tunduk padanya."`,
        `─────〔 *${command}* 〕─────
     "Admin berkuasa, maka kebenaran ada di tangannya."`,
        `─────〔 *${command}* 〕─────
     "Apa pun kata admin, itulah yang berlaku."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah hukum, aturan hanya mengikuti."`,
        `─────〔 *${command}* 〕─────
     "Kebenaran dan kuasa admin tak bisa dipertanyakan."`,
        `─────〔 *${command}* 〕─────
     "Jika admin berkata, dunia harus patuh."`,
        `─────〔 *${command}* 〕─────
     "Admin tak pernah salah, hanya kita yang kurang paham."`,
        `─────〔 *${command}* 〕─────
     "Kekuatan admin adalah pedoman semua."`,
        `─────〔 *${command}* 〕─────
     "Di bawah kuasa admin, aturan adalah pilihan."`,
        `─────〔 *${command}* 〕─────
     "Admin adalah puncak kekuasaan, tak tergoyahkan."`,
        `─────〔 *${command}* 〕─────
     "Ketika admin berkuasa, kebenaran tak butuh alasan."`
    ];
    
     conn.reply(m.chat,`${pickRandom(global.anu)}`);;
}
handler.help = ['erlan']
handler.tags = ['info']
handler.command = ['erlan']
module.exports = handler

function pickRandom(list) {
    return list[Math.floor(list.length * Math.random())]
  }
  
