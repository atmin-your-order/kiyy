let handler = async (m, { conn, participants }) => {
  let users = global.db.data.users;
  let groupMembers = participants.map(v => v.id);

  // Filter user grup yang punya tag_sw
  let leaderboard = Object.entries(users)
    .filter(([id, data]) => groupMembers.includes(id) && data.tag_sw)
    .sort((a, b) => b[1].tag_sw - a[1].tag_sw)
    .slice(0, 10);

  if (leaderboard.length === 0) {
    return conn.reply(m.chat, 'Belum ada yang tag SW nih di grup ini!', m);
  }

  let text = '*🏆 TAG SW LEADERBOARD 🏆*\n\n';
  leaderboard.forEach(([id, data], i) => {
    text += `${i + 1}. @${id.split('@')[0]} - ${data.tag_sw}x\n`;
  });

  conn.reply(m.chat, text, m, {
    mentions: leaderboard.map(([id]) => id)
  });
};

handler.help = ['tagboard'];
handler.tags = ['rpg'];
handler.command = /^tagboard$/i;
handler.group = true;

module.exports = handler;