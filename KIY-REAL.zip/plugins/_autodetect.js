const { WAMessageStubType } = require('@whiskeysockets/baileys');

module.exports = {
  before: async function before(m, { conn }) {
    // Hanya grup, bukan dari bot, dan ada stub type
    if (!m.isGroup || m.fromMe || !m.messageStubType) return;

    // Inisialisasi database
    global.db.data.chats[m.chat] = global.db.data.chats[m.chat] || {};
    let chat = global.db.data.chats[m.chat];

    if (!chat.detect) return;

    // VCard untuk quoted message
    let fkon = {
      key: {
        fromMe: false,
        participant: `0@s.whatsapp.net`,
        ...(m.chat ? { remoteJid: 'status@broadcast' } : {})
      },
      message: {
        contactMessage: {
          displayName: m.name || '',
          vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;a,;;;\nFN:RhmttDev\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
        }
      }
    };

    let edtr = `@${m.sender.split('@')[0]}`;

    switch (m.messageStubType) {
      case WAMessageStubType.GROUP_CHANGE_SUBJECT: // 21
        await conn.sendMessage(m.chat, {
          text: `${edtr} mengubah Subject Grup menjadi:\n*${m.messageStubParameters[0]}*`,
          mentions: [m.sender]
        }, { quoted: fkon });
        break;

      case WAMessageStubType.GROUP_CHANGE_ICON: // 22
        await conn.sendMessage(m.chat, {
          text: `${edtr} telah mengubah icon grup.`,
          mentions: [m.sender]
        }, { quoted: fkon });
        break;

      case WAMessageStubType.GROUP_CHANGE_INVITE_LINK: // 1, 23, 132
      case 1:
      case 23:
      case 132:
        await conn.sendMessage(m.chat, {
          text: `${edtr} *mereset* link grup!`,
          mentions: [m.sender]
        }, { quoted: fkon });
        break;

      case WAMessageStubType.GROUP_CHANGE_DESCRIPTION: // 24
        await conn.sendMessage(m.chat, {
          text: `${edtr} mengubah deskripsi grup:\n\n${m.messageStubParameters[0]}`,
          mentions: [m.sender]
        }, { quoted: fkon });
        break;

      case WAMessageStubType.GROUP_CHANGE_RESTRICT: // 25
        await conn.sendMessage(m.chat, {
          text: `${edtr} mengatur agar *${m.messageStubParameters[0] === 'on' ? 'hanya admin' : 'semua peserta'}* yang bisa mengedit info grup.`,
          mentions: [m.sender]
        }, { quoted: fkon });
        break;

      case WAMessageStubType.GROUP_CHANGE_ANNOUNCE: // 26
        await conn.sendMessage(m.chat, {
          text: `${edtr} telah *${m.messageStubParameters[0] === 'on' ? 'menutup' : 'membuka'}* grup!\nSekarang ${m.messageStubParameters[0] === 'on' ? 'hanya admin yang' : 'semua peserta'} dapat mengirim pesan.`,
          mentions: [m.sender]
        }, { quoted: fkon });
        break;

      case WAMessageStubType.GROUP_PARTICIPANT_PROMOTE: // 29
        await conn.sendMessage(m.chat, {
          text: `${edtr} menjadikan @${m.messageStubParameters[0].split('@')[0]} sebagai admin.`,
          mentions: [m.sender, m.messageStubParameters[0]]
        }, { quoted: fkon });
        break;

      case WAMessageStubType.GROUP_PARTICIPANT_DEMOTE: // 30
        await conn.sendMessage(m.chat, {
          text: `${edtr} memberhentikan @${m.messageStubParameters[0].split('@')[0]} dari admin.`,
          mentions: [m.sender, m.messageStubParameters[0]]
        }, { quoted: fkon });
        break;

      case WAMessageStubType.GROUP_CHANGE_EPHEMERAL_SETTING: // 72
        await conn.sendMessage(m.chat, {
          text: `${edtr} mengubah durasi pesan sementara menjadi *${m.messageStubParameters[0]}*.`,
          mentions: [m.sender]
        }, { quoted: fkon });
        break;

      case 123: // Nonaktifkan pesan sementara
        await conn.sendMessage(m.chat, {
          text: `${edtr} *menonaktifkan* pesan sementara.`,
          mentions: [m.sender]
        }, { quoted: fkon });
        break;

      default:
        // Log kalau ada stubType baru/tak dikenal
        console.log('Detect Log =>', {
          chat: m.chat,
          type: m.messageStubType,
          name: WAMessageStubType[m.messageStubType],
          params: m.messageStubParameters
        });
        break;
    }
  }
};