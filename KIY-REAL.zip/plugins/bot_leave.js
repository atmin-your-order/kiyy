let handler = async (m, { conn, args, text, isOwner }) => {
  if (!isOwner) throw '❌ Fitur ini hanya untuk owner!'
  if (!args[0]) throw 'Masukkan ID grup yang ingin ditinggalkan!\nContoh: .botleave 1203630xxxxxxx@g.us'

  try {
    await conn.groupLeave(args[0])
    m.reply(`✅ Sukses keluar dari grup:\n${args[0]}`)
  } catch (e) {
    m.reply('❌ Gagal keluar. Cek ID grupnya atau bot bukan bagian dari grup itu.')
  }
}

handler.help = ['botleave <id_grup>']
handler.tags = ['owner']
handler.command = /^botleave$/i
handler.owner = true

module.exports = handler