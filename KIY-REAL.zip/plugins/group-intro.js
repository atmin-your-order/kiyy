let handler = async m => {

let intro = `━━━━━━━━━━━━━━━
  ꧁ᴛʜᴇ彡Anime彡lovers꧂
━━━━━━━━━━━━━━━
Hai minna~! Yuk kenalan dulu  
Isi format ini ya:

🏙️ Asal Kota (Opsional) :
❤️ Waifu (Siapa waifumu~?) :
🎬 Anime Pertama (Yang bikin jatuh cinta sama anime?) :
📝 Nama/Panggilan (Boleh bebas~) :
🎂 Umur (Kalau gak malu hehe) :

Contoh:
🏙️ Asal Kota: Surabaya  
❤️ Waifu: Mikasa Ackerman  
🎬 Anime Pertama: Naruto  
📝 Nama/Panggilan: Raka  
🎂 Umur: 17

Ayo tunjukkan cintamu pada anime!  
Jangan malu buat isi ya  
━━━━━━━━━━━━━━━
「⚠️」No Toxic | No Spam | No War
━━━━━━━━━━━━━━━`
m.reply(intro)
}
handler.command = /^(intro)$/i

module.exports = handler
