let handler = async (m, { args }) => {
  if (args.length < 3) return m.reply('🚫 Format salah!\nGunakan: *.addlistwar girl|boy posisi nama*\nContoh: *.addlistwar boy 2 ikhsan*')

  const [unitRaw, posisiRaw, ...namaSplit] = args
  const unitAlias = unitRaw.toLowerCase()
  const nama = namaSplit.join(' ').trim()
  const pos = parseInt(posisiRaw)

  // Tentukan unit yang benar berdasar alias
  let unitName
  if (unitAlias === 'lds' || unitAlias === 'girl' || unitAlias === 'girls') {
    unitName = 'girl'
  } else if (unitAlias === 'boy' || unitAlias === 'boys') {
    unitName = 'boy'
  } else {
    return m.reply('🚫 Unit salah! Gunakan salah satu: girl, girls, lds, boy, boys')
  }

  if (isNaN(pos) || pos < 1 || pos > 4) return m.reply('🚫 Posisi harus angka antara 1 sampai 4.')

  if (!nama) return m.reply('🚫 Nama tidak boleh kosong.')

  const jid = m.chat
  const chat = global.db.data.chats[jid] ??= {}
  chat.warlist ??= { girls: [], boys: [] }

  if (unitName === 'girl') {
    chat.warlist.girls[pos - 1] = nama
    m.reply(`✅ Nama "${nama}" berhasil ditambahkan ke LADIES posisi ke-${pos}.`)
  } else {
    chat.warlist.boys[pos - 1] = nama
    m.reply(`✅ Nama "${nama}" berhasil ditambahkan ke BOYS posisi ke-${pos}.`)
  }
}

handler.command = /^addlistwar$/i
handler.group = true
module.exports = handler