let handler = async (m, { conn, text, participants, isAdmin, isOwner }) => {
  if (!isAdmin && !isOwner) throw 'Perintah ini hanya untuk admin grup atau owner bot!'

  let teks = `⋙ *PESAN DARI ADMIN GROUP* ⋘\n\n*${text ? text : 'Nothing'}*\n\n`
  for (let mem of participants) {
    teks += ` @${mem.id.split('@')[0]}\n`
  }
  teks += `___________________________________________`

  await conn.sendMessage(m.chat, {
    text: teks,
    mentions: participants.map(a => a.id)
  }, { quoted: m }) // ini untuk konteks reply
}

handler.help = ['tagall <pesan>']
handler.tags = ['group']
handler.command = /^(tagall)$/i
handler.group = true

module.exports = handler