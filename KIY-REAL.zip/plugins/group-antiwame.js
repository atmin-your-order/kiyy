let handler = m => m

let waMeRegex = /wa\.me\/(\d{9,15})/i

handler.before = async function (m, { conn, isBotAdmin, isAdmin }) {
  if ((m.isBaileys && m.fromMe) || m.fromMe || !m.isGroup || !m.text) return true

  let chat = global.db.data.chats[m.chat]
  let isWaMeLink = waMeRegex.exec(m.text)

  if (chat.antiWame && isWaMeLink) {
    // Ambil info owner
    let groupMetadata = await conn.groupMetadata(m.chat)
    let groupOwner = groupMetadata.owner || groupMetadata.participants.find(p => p.admin === 'superadmin')?.id

    // Abaikan admin dan owner
    if (isAdmin || m.sender === groupOwner) {
      return m.reply('*「 ANTI WAME 」*\n\nLink wa.me terdeteksi, tapi kamu admin/owner jadi tidak dihapus.')
    }

    if (!isBotAdmin) return m.reply('*Bot bukan admin, tidak bisa menghapus pesan.*')

    await conn.sendMessage(m.chat, { delete: m.key })
    await conn.sendMessage(m.chat, {
      text: `*「 ANTI WAME 」*\n\nTerdeteksi @${m.sender.split('@')[0]} mengirim link wa.me dan pesannya telah dihapus.`,
      mentions: [m.sender]
    })
  }

  return true
}

module.exports = handler