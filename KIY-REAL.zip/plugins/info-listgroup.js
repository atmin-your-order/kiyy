let handler = async (m, { conn }) => {
    // get all chats
    let chats = [];
    if (conn.chats && typeof conn.chats.all === 'function') {
        chats = conn.chats.all();
    } else if (conn.chats && typeof conn.chats === 'object') {
        chats = Object.values(conn.chats);
    }
    // filter group chats
    let groups = chats.filter(chat => chat && chat.id && chat.id.endsWith('@g.us'));
    if (!groups || groups.length === 0) {
        return conn.reply(m.chat, 'Tidak ada grup yang saya ikuti.', m);
    }
    let blocks = [];
    let count = 0;
    for (let chat of groups) {
        let jid = chat.id;
        let metadata;
        try {
            metadata = await conn.groupMetadata(jid);
        } catch (e) {
            continue; // skip if cannot fetch metadata
        }
        count++;
        let name = metadata.subject || 'Tidak ada nama';
        let memberCount = 0;
        if (metadata.participants) {
            memberCount = metadata.participants.length;
        } else if (metadata.size) {
            memberCount = metadata.size;
        }
        let statusPesan = metadata.announce ? 'Tertutup' : 'Terbuka';
        let created = 'Unknown';
        if (metadata.creation) {
            created = new Date(metadata.creation * 1000)
                        .toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });
        }
        // Sewa status
        let sewaStatus = 'Belum diatur';
        let sewaRemaining = '0 hari';
        let sewaEnd = 0;
        if (global.db && global.db.data && global.db.data.sewaGroups && global.db.data.sewaGroups[jid]) {
            sewaEnd = global.db.data.sewaGroups[jid];
        } else if (global.sewa && global.sewa[jid]) {
            sewaEnd = global.sewa[jid];
        }
        if (sewaEnd) {
            let now = Math.floor(Date.now() / 1000);
            if (now <= sewaEnd) {
                sewaStatus = 'Aktif';
                let diff = (sewaEnd - now);
                let days = Math.floor(diff / 86400);
                let hours = Math.floor((diff % 86400) / 3600);
                sewaRemaining = days + ' hari ' + hours + ' jam';
            } else {
                sewaStatus = 'Kadaluarsa';
                sewaRemaining = '0 hari';
            }
        }
        // Group link
        let link = '-';
        try {
            let inviteCode = await conn.groupInviteCode(jid);
            link = 'https://chat.whatsapp.com/' + inviteCode;
        } catch (e) {
            link = '-';
        }
        let block = `${count}. *Nama Grup:* ${name}\n`;
        block += `   *Jumlah Member:* ${memberCount}\n`;
        block += `   *Status Pesan:* ${statusPesan}\n`;
        block += `   *Tanggal Dibuat:* ${created}\n`;
        block += `   *Status Sewa:* ${sewaStatus}\n`;
        block += `   *Sisa Waktu Sewa:* ${sewaRemaining}\n`;
        block += `   *Link Grup:* ${link}`;
        blocks.push(block);
    }
    let teks = blocks.join('\n\n\n');
    conn.reply(m.chat, teks, m);
}
handler.command = ['listgc'];
handler.help = ['listgc'];
handler.tags = ['info'];
handler.admin = false;
handler.botAdmin = false;
handler.group = false;
module.exports = handler;