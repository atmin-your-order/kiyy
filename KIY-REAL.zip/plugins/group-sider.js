let handler = async (m, { conn, args, groupMetadata }) => {
    await conn.sendPresenceUpdate('composing', m.chat)

    global.db.data.chatStats = global.db.data.chatStats || {}
    let db = global.db.data.chatStats
    let now = new Date()
    let date = now.toISOString().split('T')[0] // format YYYY-MM-DD
    let MIN_CHAT = global.db.data.minChat || 10 // default 10

    let member = groupMetadata.participants.map(v => v.id)
    let total = 0
    const sider = []

    for (let id of member) {
        let user = groupMetadata.participants.find(u => u.id === id)
        let todayChat = (db[id]?.daily?.[date] || 0)
        let totalChat = (db[id]?.total || 0)
        let lastChat = db[id]?.lastChat ? formatDate(db[id].lastChat) : "Belum Pernah"

        if (todayChat < MIN_CHAT && !user.admin) {
            total++
            sider.push({
                id,
                todayChat,
                totalChat,
                lastChat
            })
        }
    }

    if (!args[0]) {
        return conn.reply(m.chat, ` Gunakan perintah dengan opsi:\n1. \`sider list\` untuk melihat yang chatnya kurang dari *${MIN_CHAT}*\n2. \`sider kick\` untuk keluarkan mereka`, m)
    }

    if (args[0] === 'list') {
        if (total === 0) return conn.reply(m.chat, ` Tidak ada sider (semua sudah  ${MIN_CHAT} chat hari ini).`, m)

        const groupName = await conn.getName(m.chat)
        const message = `*${total}/${member.length}* anggota grup *${groupName}* chatnya kurang dari *${MIN_CHAT}*:\n\n` +
            sider.map(v => 
                ` @${v.id.replace(/@.+/, '')}\n   Today: ${v.todayChat}\n   Total: ${v.totalChat}\n   Last: ${v.lastChat}`
            ).join('\n\n')

        return conn.reply(m.chat, message, m, { contextInfo: { mentionedJid: sider.map(v => v.id) } })
    }

    if (args[0] === 'kick') {
        if (total === 0) return conn.reply(m.chat, ` Tidak ada yang perlu di-kick.`, m)

        for (const user of sider) {
            try {
                await conn.groupParticipantsUpdate(m.chat, [user.id], 'remove')
            } catch (e) {
                console.error(e)
            }
        }

        return conn.reply(m.chat, ` Berhasil mengeluarkan *${total}* anggota karena chat < ${MIN_CHAT} hari ini.`, m)
    }

    return conn.reply(m.chat, ` Opsi tidak valid. Gunakan \`sider list\` atau \`sider kick\`.`, m)
}

handler.help = ['sider']
handler.tags = ['group']
handler.command = /^(sider|gcsider)$/i
handler.group = true
handler.admin = true
handler.botAdmin = true

// simpan jumlah chat user tiap kali ada pesan
handler.before = async function (m) {
    if (!m.isGroup) return
    global.db.data.chatStats = global.db.data.chatStats || {}
    let db = global.db.data.chatStats
    let id = m.sender
    let now = new Date()
    let date = now.toISOString().split('T')[0]

    if (!db[id]) {
        db[id] = { total: 0, daily: {}, lastChat: 0 }
    }
    db[id].total++
    db[id].lastChat = now.getTime()
    db[id].daily[date] = (db[id].daily[date] || 0) + 1
}

module.exports = handler

// Format tanggal biar enak dibaca
function formatDate(ms) {
    let d = new Date(ms)
    return d.toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })
}