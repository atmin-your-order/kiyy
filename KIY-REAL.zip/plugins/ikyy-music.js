let handler = async (m, { conn, command }) => {
  let number = command.replace('music', ''); // Ambil angkanya, contoh: music45 -> 45
  let url = `https://raw.githubusercontent.com/Rez4-3yz/Music-rd/master/music/music${number}.mp3`;

  try {
    await conn.sendMessage(m.chat, {
      audio: { url },
      mimetype: 'audio/mpeg',
      fileName: `music${number}.mp3`,
      ptt: false
    }, { quoted: m });
  } catch (e) {
    throw `Gagal mengirim music${number}.mp3\nPastikan file tersedia di repo GitHub.`;
  }
};

// Registrasi command dari music1 sampai music132
handler.command = Array.from({ length: 130 }, (_, i) => new RegExp(`^music${i + 1}$`, 'i'));
handler.tags = ['audio'];
handler.help = Array.from({ length: 130 }, (_, i) => `music${i + 1}`);

module.exports = handler;