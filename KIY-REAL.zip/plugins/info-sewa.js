let fetch = require('node-fetch')

let handler = async (m, { conn, command }) => {
    let buffer = await fetch(`https://files.catbox.moe/8fdda4.jpeg`).then(res => res.buffer())
    conn.sendFile(m.chat, buffer, 'hasil.jpg', `*Jika Ingin Donasi Dana Owner Adalah 6283133328750 Dan Jika Ingin Sewa, Transfer Ke Nomor Tersebut Dan Kirim Bukti Ke Owner.*`, m)
}

handler.help = handler.command = ['donasi','donate','sewa','sewabot','belibot']
handler.tags = ['main']
module.exports = handler
