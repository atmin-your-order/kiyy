global.owner = ['6283133328750', '6285150517856']  
global.mods = ['6283133328750'] 
global.prems = ['6283133328750']
global.nameowner = 'Rizky / Ikyyz'
global.numberowner = '6283133328750'
global.mail = 'sanjaya28051@gmail.vom' 
global.gc = 'https://chat.whatsapp.com/LYHEpztwGu5EYUa9cQtT19'
global.instagram = 'https://instagram.com/rizky_sanjayaaaa'
global.wm = '© CUYAxIKYY'
global.wait = '_*Sabar Ya Sayangku Lagi Di Proses...*_'
global.eror = '_*Servernya Ngambek Nihh Lapor Owner Dong*_'
global.stiker_wait = '*⫹⫺ Sticker lagi dibikin jadi.. Sabar Ya Sayangkuu...*'
global.packname = 'Dibuat Oleh'
global.author = 'Yuta-Bot by SASAxIKYY'
global.maxwarn = '7' // Peringatan maksimum
global.antiporn = true // Auto delete pesan porno (bot harus admin)

//INI WAJIB DI ISI!//
global.lann = 'ikyyzzx' 
//Daftar terlebih dahulu https://api.betabotz.eu.org

//INI OPTIONAL BOLEH DI ISI BOLEH JUGA ENGGA//
global.btc = 'YOUR_APIKEY_HERE'
//Daftar https://api.botcahx.eu.org 

global.APIs = {   
  lann: 'https://api.betabotz.eu.org',
  btc: 'https://api.botcahx.eu.org'
}
global.APIKeys = { 
  'https://api.betabotz.eu.org': global.lann, 
  'https://api.botcahx.eu.org': global.btc //OPSIONAL
}

let fs = require('fs')
let chalk = require('chalk')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  delete require.cache[file]
  require(file)
})
