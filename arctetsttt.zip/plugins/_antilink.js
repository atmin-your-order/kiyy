let handler = m => m

let linkRegex = /chat\.whatsapp\.com\/([0-9A-Za-z]{20,24})/i
handler.before = async function (m, { isBotAdmin }) {
  if ((m.isBaileys && m.fromMe) || m.fromMe || !m.isGroup) return true

  let chat = global.db.data.chats[m.chat]
  let isGroupLink = linkRegex.exec(m.text)

  if (chat.antiLink && isGroupLink) {
    let linkGC = 'https://chat.whatsapp.com/' + await conn.groupInviteCode(m.chat)
    let isLinkconnGc = new RegExp(linkGC, 'i')
    let isgclink = isLinkconnGc.test(m.text)

    if (isgclink) return conn.sendMessage(m.chat, {
      text: '*「 ANTI LINK 」*\n\nLink grup ini sendiri, jadi tidak dihapus.'
    })

    if (!isBotAdmin) return conn.sendMessage(m.chat, {
      text: '*Bot bukan admin, tidak bisa hapus pesan.*'
    })

    await conn.sendMessage(m.chat, { delete: m.key })

    await conn.sendMessage(m.chat, {
      text: `*「 ANTI LINK 」*\n\nDetected @${m.sender.split('@')[0]} mengirim link grup WhatsApp!\nPesan telah dihapus karena admin mengaktifkan *antilink*.\n\nKetik *.disable antilink* untuk mematikannya.`,
      mentions: [m.sender]
    })
  }

  return true
}

module.exports = handler