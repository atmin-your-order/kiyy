const axios = require('axios');

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `Masukan URL!\n\nContoh:\n${usedPrefix + command} https://youtu.be/4rDOsvzTicY`;

  m.reply('⏳ Sedang memproses, tunggu sebentar ya...');

  try {
    const response = await axios.get(`https://api.betabotz.eu.org/api/download/ytmp4?url=${text}&apikey=${lann}`);
    const res = response.data.result;

    if (!res || !res.mp4) throw 'Gagal mengambil video. Link tidak valid atau API bermasalah.';

    const { mp4, id, title, source, duration } = res;

    const capt = `*YT MP4*\n\n` +
      `◦ *ID* : ${id}\n` +
      `◦ *Judul* : ${title}\n` +
      `◦ *Sumber* : ${source}\n` +
      `◦ *Durasi* : ${duration}\n`;

    await conn.sendMessage(m.chat, {
      video: { url: mp4 },
      mimetype: 'video/mp4',
      caption: capt
    }, { quoted: m });

  } catch (err) {
    console.error(err);
    m.reply('❌ Gagal mengambil data video. Mungkin link salah, video private, atau API limit.');
  }
};

handler.help = ['ytmp4 <url>'];
handler.tags = ['downloader'];
handler.command = /^(ytmp4)$/i;
handler.limit = true;

module.exports = handler;