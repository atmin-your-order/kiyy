const { generateWAMessageFromContent } = require('@adiwajshing/baileys');
let fs = require('fs');
let path = require('path');
let fetch = require('node-fetch');
let levelling = require('../lib/levelling');
const moment = require('moment-timezone');
const ffmpeg = require('fluent-ffmpeg');
const ffmpegPath = require('ffmpeg-static');
ffmpeg.setFfmpegPath(ffmpegPath);

let arrayMenu = [
    'all', 'ai', 'audio', 'main', 'database', 'downloader', 'rpg', 'rpgG', 'sticker', 'advanced', 'xp', 'fun', 'game', 'github', 'group', 'image', 'info', 'internet', 'islam', 'kerang', 'maker', 'nsfw', 'news', 'owner', 'voice', 'quotes', 'store', 'stalk', 'shortlink', 'tools', 'anonymous'
];

const allTags = arrayMenu.reduce((acc, tag) => {
    acc[tag] = `MENU ${tag.toUpperCase()}`;
    return acc;
}, {});
allTags['all'] = 'SEMUA MENU';

const defaultMenu = {
    before: `Hi %name\n Aku Adalah Bot Otomatis Yaitu DRN•CHAGO Bisa Membantu Mu Dalam Segala Hal Dan DRN•CHAGO Bot Dirancang Untuk Kalian.\n\nJangan Lupa Join Channel\n1. https://whatsapp.com/channel/0029Vb652o9G3R3dlONb700V \n\n2. https://whatsapp.com/channel/0029Vb5yOOBFMqrOmh4sj817 \n\n◦ *Library:* Baileys\n◦ *Function:* Assistant\n\n┌  ◦ Waktu Aktif : %uptime\n│  ◦ Tanggal : %date\n│  ◦ Waktu : %time\n└  ◦ Kode Awalan : *[ %_p ]*`.trimStart(),
    header: '┌  ◦ *%category*',
    body: '│  ◦ %cmd %islimit %isPremium',
    footer: '└  ',
    after: `*Note:* Ketik .menu <category> untuk melihat menu spesifik\nContoh: .menu tools`
};

let handler = async (m, { conn, usedPrefix: _p, args = [], command }) => {
    try {
        let { exp, limit, level } = global.db.data.users[m.sender];
        let name = `@${m.sender.split`@`[0]}`;
        let teks = args[0] || '';
        
        let d = new Date();
        let locale = 'id';
        let date = d.toLocaleDateString(locale, { day: 'numeric', month: 'long', year: 'numeric' });
        let time = d.toLocaleTimeString(locale, { hour: 'numeric', minute: 'numeric', second: 'numeric' });
        let uptime = clockString(process.uptime() * 1000);
        
        let help = Object.values(global.plugins).filter(plugin => !plugin.disabled).map(plugin => ({
            help: Array.isArray(plugin.help) ? plugin.help : [plugin.help],
            tags: Array.isArray(plugin.tags) ? plugin.tags : [plugin.tags],
            limit: plugin.limit,
            premium: plugin.premium
        }));

        let loadingFrames = [
            '*[ ⚀ ] Loading...*\n_*▰▱▱▱▱*_',
            '*[ ⚁ ] Loading...*\n_*▱▰▱▱▱*_',
            '*[ ⚂ ] Loading...*\n_*▱▱▰▱▱*_',
            '*[ ⚃ ] Loading...*\n_*▱▱▱▰▱*_',
            '*[ ⚄ ] Loading...*\n_*▱▱▱▱▰*_',
            '*[ ⚀ ] Loading...*\n_*▰▱▱▱▱*_',
            '*[ ⚁ ] Loading...*\n_*▱▰▱▱▱*_',
            '*[ ⚂ ] Loading...*\n_*▱▱▰▱▱*_',
            '*[ ⚃ ] Loading...*\n_*▱▱▱▰▱*_',
            '*[ ⚄ ] Loading...*\n_*▱▱▱▱▰*_',
            '*[ ⚀ ] Loading...*\n_*▰▱▱▱▱*_',
            '*[ ⚁ ] Loading...*\n_*▱▰▱▱▱*_',
            '*[ ⚂ ] Loading...*\n_*▱▱▰▱▱*_',
            '*[ ⚃ ] Loading...*\n_*▱▱▱▰▱*_',
            '*[ ⚄ ] Loading...*\n_*▱▱▱▱▰*_',
            '*[ ✔ ] Selesai!*'
        ];
        let { key } = await conn.sendMessage(m.chat, { text: loadingFrames[0] }, { quoted: m });
        for (let i = 1; i < loadingFrames.length; i++) {
            await new Promise(resolve => setTimeout(resolve, 200));
            await conn.sendMessage(m.chat, { text: loadingFrames[i], edit: key });
        }

        let text;
        if (!teks) {
            text = `${defaultMenu.before}\n\n┌  ◦ *DAFTAR MENU*\n`;
            for (let tag of arrayMenu) {
                text += `│  ◦ ${_p}menu ${tag}\n`;
            }
            text += `└  \n\n${defaultMenu.after}`;
        } else if (teks.toLowerCase() === 'all') {
            text = `${defaultMenu.before}\n\n`;
            for (let tag of arrayMenu) {
                let categoryCommands = help.filter(menu => menu.tags.includes(tag));
                if (categoryCommands.length > 0) {
                    text += `${defaultMenu.header.replace(/%category/g, allTags[tag])}\n`;
                    for (let menu of categoryCommands) {
                        for (let help of menu.help) {
                            text += defaultMenu.body
                                .replace(/%cmd/g, _p + help)
                                .replace(/%islimit/g, menu.limit ? '(Ⓛ)' : '')
                                .replace(/%isPremium/g, menu.premium ? '(Ⓟ)' : '') + '\n';
                        }
                    }
                    text += `${defaultMenu.footer}\n\n`;
                }
            }
            text += defaultMenu.after;
        } else {
            if (!allTags[teks]) return m.reply(`Menu "${teks}" tidak tersedia.\nSilakan ketik ${_p}menu untuk melihat daftar menu.`);
            text = `${defaultMenu.before}\n\n${defaultMenu.header.replace(/%category/g, allTags[teks])}\n`;
            let categoryCommands = help.filter(menu => menu.tags.includes(teks));
            for (let menu of categoryCommands) {
                for (let help of menu.help) {
                    text += defaultMenu.body
                        .replace(/%cmd/g, _p + help)
                        .replace(/%islimit/g, menu.limit ? '(Ⓛ)' : '')
                        .replace(/%isPremium/g, menu.premium ? '(Ⓟ)' : '') + '\n';
                }
            }
            text += `${defaultMenu.footer}\n\n${defaultMenu.after}`;
        }

        return sendMenu(m, conn, text, { name, uptime, date, time, _p });

    } catch (e) {
        console.error(e);
        conn.reply(m.chat, 'Maaf, menu sedang error', m);
    }
};

handler.help = ['menu'];
handler.tags = ['main'];
handler.command = /^(menu|help|bot)$/i;
handler.exp = 3;
module.exports = handler;

function sendMenu(m, conn, text, replace) {
    text = text.replace(new RegExp(`%(${Object.keys(replace).sort((a, b) => b.length - a.length).join('|')})`, 'g'), (_, name) => '' + replace[name]);

    const videoPath = './media/menu.mp4';
    const tempVideo = './media/menu_temp.mp4';
    const audioPath = './media/menu.mp3';

    if (!fs.existsSync(videoPath)) {
        return conn.reply(m.chat, 'Video tidak ditemukan.', m);
    }

    if (fs.existsSync(tempVideo)) {
        fs.unlinkSync(tempVideo);
    }

    ffmpeg(videoPath)
        .setStartTime(0)
        .setDuration(6)
        .output(tempVideo)
        .on('end', async () => {
            await conn.sendMessage(m.chat, {
                video: fs.readFileSync(tempVideo),
                caption: text,
                mimetype: 'video/mp4',
                gifPlayback: true,
                contextInfo: {
                    mentionedJid: [m.sender],
                    externalAdReply: {
                        title: replace.date,
                        mediaType: 1,
                        previewType: 0,
                        renderLargerThumbnail: true,
                        thumbnailUrl: 'https://api.betabotz.eu.org/api/tools/uploader-get?id=QWdBQ0FnVUFBeUVHQUFTclJWR2lBQUVHSnZKb3FlM1RPZjFfUmxMNjVrTF8yaHdDVDBNa0NRQUNxTkV4RzN0TlVWVXFCMldGTnBSVHBRRUFBd0lBQTNnQUF6WUU6OjU4NjYyNzM5Njg6QUFFcHVLbFNGRW9Pd2ZScF9kUG9zVlZPbWVCa2JybWhlMFk=&mime=image/jpeg',
                        sourceUrl:'https://whatsapp.com/channel/0029Vb652o9G3R3dlONb700V'
                    }
                },
                mentions: [m.sender]
            });

            if (fs.existsSync(audioPath)) {
                await conn.sendMessage(m.chat, {
                    audio: fs.readFileSync(audioPath),
                    mimetype: 'audio/mp4',
                    ptt: false
                }, { quoted: m });
            }
        })
        .on('error', err => {
            console.error('FFmpeg error:', err);
            conn.reply(m.chat, 'Gagal memproses video.', m);
        })
        .run();
}

function clockString(ms) {
    let h = Math.floor(ms / 3600000);
    let m = Math.floor(ms / 60000) % 60;
    let s = Math.floor(ms / 1000) % 60;
    return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':');
}