const fetch = require('node-fetch');

const handler = async (m, { conn, args }) => {
  try {
    const sadNumber = parseInt(args[0], 10);

    if (isNaN(sadNumber) || sadNumber < 1 || sadNumber > 34) {
      return conn.reply(m.chat, 'Masukkan nomor antara 1 dan 34\nContoh: .sad 2', m);
    }

    let contextInfo = {
      externalAdReply: {
        showAdAttribution: true,
        title: `🎼 Melodi Sedih: Perjalanan Emosi 🎵`,
        body: `💔 Biarkan lagu-lagu ini menyentuh hatimu. Klik untuk mendengarkan.`,
        description: 'Masuki kedalaman kesedihan...',
        mediaType: 2,
        thumbnailUrl:'https://files.catbox.moe/4tk2t3.jpeg',
        mediaUrl: 'https://whatsapp.com/channel/0029VbADHuw6xCSW1gN7d30u'
      }
    };

    const sadURL = `https://github.com/Rangelofficial/Sad-Music/raw/main/audio-sad/sad${sadNumber}.mp3`;
    const response = await fetch(sadURL);
    if (!response.ok) throw new Error("Gagal mengunduh audio");

    const sadBuffer = await response.buffer();
    await conn.sendMessage(m.chat, {
      audio: sadBuffer,
      mimetype: 'audio/mp4',
      ptt: true,
      contextInfo
    }, { quoted: m });

  } catch (error) {
    await conn.reply(m.chat, "Terjadi kesalahan saat mengunduh atau mengirim audio.", m);
    console.error(error);
  }
};

handler.help = ['sad'];
handler.command = ['sad'];
handler.tags = ['audio'];
handler.onlyGroup = true;
module.exports = handler;