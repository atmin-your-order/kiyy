let handler = async (m, { conn, isOwner }) => {
  if (!isOwner) throw '❌ Fitur ini hanya untuk owner!'

  const chats = conn.chats || {}
  const groups = Object.keys(chats).filter(jid => jid.endsWith('@g.us'))

  if (groups.length === 0) return m.reply('Bot belum masuk ke grup manapun.')

  let text = 'Daftar grup yang diikuti bot:\n\n'

  for (const jid of groups) {
    let name = conn.chats[jid]?.subject || '' // coba ambil dari subject
    if (!name) {
      try {
        const metadata = await conn.groupMetadata(jid)
        name = metadata.subject || jid
      } catch {
        name = jid
      }
    }
    text += `• ${name}\nJID: ${jid}\n\n`
  }

  return m.reply(text)
}

handler.help = ['listjoin']
handler.tags = ['owner']
handler.command = /^listjoin$/i
handler.owner = true

module.exports = handler
//BY IKYY
//WA? 083133328750
//PAKAI BOLEH, HAPUS CREDITS YAA MALU LAH TOLOL
//DESIGN, CODING, LOGIC BY IKYY