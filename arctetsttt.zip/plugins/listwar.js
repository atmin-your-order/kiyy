let handler = async (m, { conn, args }) => {
  const jid = m.chat
  const chat = global.db.data.chats[jid] ??= {}
  chat.warlist ??= { girls: [], boys: [] }

  let girls = chat.warlist.girls
  let boys = chat.warlist.boys
  let type = (args[0] || '').toLowerCase()

  const unitLDS = `
⚰️🖤 *UNIT I — LADIES OF DEATH*  
*CALLSIGN: BLACK SERAPHIM*  
_"They wear beauty like a mask.  
What’s underneath... is fatal."_

1. ${girls[0] || '-'} — *"Smiles while you bleed"* 🐝🩸  
2. ${girls[1] || '-'} — *"She kisses death on the lips"* 🐍☠️  
3. ${girls[2] || '-'} — *"Doesn’t walk. She hunts."* 🔫🕯️  
4. ${girls[3] || '-'} — *"Sweet voice. Sharp bullets."* 🐈‍⬛💀`

  const unitBOYS = `
⚰️🔥 *UNIT II — BOYS OF RUIN*  
*CALLSIGN: CRIMSON DIVISION*  
_"You don’t face us._  
_You face what fear becomes."_

1. ${boys[0] || '-'} — *"Silent. Deadly. Forgotten."* 🪦🔕  
2. ${boys[1] || '-'} — *"You’re dead before you see him"* 👻🔫  
3. ${boys[2] || '-'} — *"Fire that never needs to reload"* 🔥🌪️  
4. ${boys[3] || '-'} — *"Eats fear. Spits corpses."* 🐺🩸`

  if (type === 'boy') return m.reply(unitBOYS.trim())
  if (type === 'girl' || type === 'lds') return m.reply(unitLDS.trim())

  const header = `🕯️☠️ *_ALLBASE HEROES PRIDE_* ☠️🕯️  
*BLACK SCRIPT: SG BLOODLIST // 2025*  
_"Don’t call it a match. Call it an execution."_

⛓️ *DIVISION FORMAT:*  
🩸 *SG ONLY*  
🩸 *4 LADIES — 4 BOYS*  
🩸 *ONE SHOT • ONE DEATH*  
🩸 *ZERO APOLOGIES*  
🩸 *MENTAL DOMINATION FIRST*

*We don’t push. We erase.*`

  const footer = `🧠 *PSYCHO WAR PROTOCOL:*

🔒 *SG ONLY* — No rifles. No mercy.  
🔒 *NO TOXIC* — Just mental destruction.  
🔒 *NO ESCAPE* — Bullets hit after the fear.  
🔒 *WAR STATUS:* ☠️ *ONLINE*

––––––––––––––––––––––––

🕯️ *CLAN: ALLBASE HEROES PRIDE*

_"Angels fell for love._  
_We fall for blood."_

📆 *CODE ENGAGED: JUNE 2025*  
🚷 *RECRUITMENT OPEN • TARGETS OPEN*

––––––––––––––––––––––––

🪓 *This isn’t just a warlist.*  
⚰️ *It’s a coordinated slaughter.*

📩 *Want to test us?*  
*Sign your own death form.*

> *©ikyy — Aku sistem yang membuat mereka terlihat kuat.*`

  let teks = header + '\n\n––––––––––––––––––––––––\n'
  let any = false

  // cek ada minimal 1 nama girls
  if (girls.some(x => x && x.trim() !== '')) {
    teks += unitLDS.trim() + '\n\n––––––––––––––––––––––––\n'
    any = true
  }

  // cek ada minimal 1 nama boys
  if (boys.some(x => x && x.trim() !== '')) {
    teks += unitBOYS.trim() + '\n\n––––––––––––––––––––––––\n'
    any = true
  }

  if (any) {
    teks += footer
    return m.reply(teks.trim())
  } else {
    return m.reply('⚠️ Data belum lengkap. Gunakan:\n.listwar boy\n.listwar girl/lds')
  }
}

handler.command = /^listwar$/i
handler.group = true
module.exports = handler