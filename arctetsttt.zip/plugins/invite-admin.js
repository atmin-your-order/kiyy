let handler = async (m, { conn, args, isOwner }) => {
  if (!isOwner) return m.reply('Fitur ini hanya untuk owner bot!')

  let number = args[0]
  let groupId = args[1]

  if (!number || !groupId) return m.reply('Format salah!\nContoh: .invite 628xxxx 120xxx@g.us')
  if (!groupId.endsWith('@g.us')) return m.reply('ID grup tidak valid!')

  let jid = number.replace(/\D/g, '') + '@s.whatsapp.net'

  try {
    const groupMetadata = await conn.groupMetadata(groupId)
    const botInGroup = groupMetadata.participants.find(p => p.id === conn.user.jid)
    if (!botInGroup || !botInGroup.admin) return m.reply('Bot bukan admin atau tidak ada di grup.')

    await conn.groupParticipantsUpdate(groupId, [jid], 'add')
    m.reply(`Berhasil mengundang ${number} ke grup!`)
  } catch (e) {
    console.error(e)
    m.reply('Gagal mengundang. Pastikan nomor belum ada di grup dan bot punya akses admin.')
  }
}

handler.help = ['invite <nomor> <id_grup>']
handler.tags = ['owner']
handler.command = /^invite$/i
handler.owner = true // hanya owner

module.exports = handler