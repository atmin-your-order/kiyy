let handler = async (m, { conn, command, usedPrefix, text }) => {

  const warningText = `
 *PERINGATAN KONTEN HARAM - ISLAM MELARANG!*

 *Allah SWT berfirman dalam Al-Qur'an:*

 QS. An-Nur: 30  
** : **

                

**Latin:**  
*Wa qul lil-muminna yaghudd min abshrihim wa yafa furjahum, lika azk lahum, innallha khabrum bim yanan.*

**Artinya:**  
_"Katakanlah kepada laki-laki yang beriman, hendaklah mereka menahan pandangannya dan memelihara kemaluannya. Yang demikian itu lebih suci bagi mereka. Sungguh, Allah Maha Mengetahui apa yang mereka perbuat."_



 QS. An-Nur: 31  
** : **

      ...

**Latin:**  
*Wa qul lil-muminti yaghuna min abshrihinna wa yafana furjahunna...*

**Artinya:**  
_"Dan katakanlah kepada wanita yang beriman, hendaklah mereka menahan pandangannya dan memelihara kemaluannya..."_



 *Islam melarang keras membuka, melihat, atau menyebarkan konten pornografi atau cabul.*

 Bahkan *mendekati zina pun dilarang*, karena itu adalah jalan kehancuran jiwa dan hati.



 Jika kamu sedang berjuang meninggalkan hal ini, *sebaiknya jangan dilanjutkan* dan mintalah pertolongan Allah.

Namun jika kamu tetap ingin mengakses dengan sadar dan tanggung jawab pribadi, maka ketik:

\`${usedPrefix + command} proceed\`
`;

  // Cek apakah user sudah ketik 'proceed'
  if (!text.includes('proceed')) {
    return conn.reply(m.chat, warningText.trim(), m);
  }

  try {
    const lann = global.lann; // pastikan ini sudah didefinisikan di config.js
    let res;

    switch (command) {
      case 'gay': case 'ahegao': case 'ass': case 'bdsm': case 'blowjob': case 'cuckold':
      case 'cum': case 'ero': case 'femdom': case 'foot': case 'gangbang': case 'glasses':
      case 'hentai': case 'gifs': case 'jahy': case 'manga': case 'masturbation':
      case 'neko': case 'neko2': case 'orgy': case 'panties': case 'pussy':
      case 'tentacles': case 'yuri': case 'thighs': case 'zettai':
        res = `https://api.betabotz.eu.org/api/nsfw/${command}?apikey=${lann}`;
        break;
      default:
        throw ' Perintah tidak ditemukan!';
    }

    if (command === 'gifs') {
      await conn.sendFile(m.chat, res, null, '', m);
    } else {
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
  } catch (err) {
    console.error(err);
    throw ' Gagal memuat konten. Coba lagi nanti atau cek API key.';
  }
};

// Daftar perintah NSFW yang didukung
handler.command = handler.help = [
  'gay','ahegao','ass','bdsm','blowjob','cuckold','cum','ero',
  'femdom','foot','gangbang','glasses','hentai','gifs','jahy',
  'manga','masturbation','neko','neko2','orgy','panties','pussy',
  'tentacles','yuri','thighs','zettai'
];
handler.tags = ['nsfw'];
handler.limit = true;

module.exports = handler;