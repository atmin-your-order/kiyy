let handler = async (m, { text, conn, isOwner, isAdmin, args, command }) => {
    if (m.isBaileys) return;

    // Hanya admin grup atau owner bot yang bisa pakai
    if (!(isAdmin || isOwner)) {
        global.dfail('admin', m, conn);
        throw false;
    }

    // Ambil ID pemilik grup
    let ownerGroup = m.chat.split`-`[0] + "@s.whatsapp.net";

    // Jika reply pesan
    if (m.quoted) {
        let usr = m.quoted.sender;
        if (usr === ownerGroup || usr === conn.user.jid) return;
        await conn.groupParticipantsUpdate(m.chat, [usr], "promote");
        m.reply(`Sukses menaikkan jabatan @${usr.split('@')[0]}!`, null, { mentions: [usr] });
        return;
    }

    // Jika tag atau input nomor
    if (!args[0] && !m.mentionedJid[0]) throw `Tag atau ketik nomor yang ingin dinaikkan jabatannya!`;

    let users = [];

    // Jika disebut (tag)
    if (m.mentionedJid.length) {
        users.push(...m.mentionedJid);
    }

    // Jika input nomor
    if (args[0] && args[0].match(/[0-9]/)) {
        for (let arg of args) {
            let number = arg.replace(/[^0-9]/g, '');
            if (number.length <= 5) continue;
            let jid = number + "@s.whatsapp.net";
            users.push(jid);
        }
    }

    // Filter agar tidak promote owner group atau bot
    users = users.filter(u => u !== ownerGroup && u !== conn.user.jid);

    for (let user of users) {
        await conn.groupParticipantsUpdate(m.chat, [user], "promote");
        m.reply(`Sukses promote @${user.split('@')[0]}!`, null, { mentions: [user] });
    }
};

handler.help = ['promote @user / 628xxxx'];
handler.tags = ['group'];
handler.command = /^(promo?te|admin|\^)$/i;

handler.group = true;
handler.botAdmin = true;
handler.admin = false; // Owner bisa pakai, walau bukan admin grup
handler.fail = null;

module.exports = handler;