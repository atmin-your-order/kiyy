global.owner = ['6289531035137']  
global.mods = ['6289531035137'] 
global.prems = ['6289531035137']
global.nameowner = 'DRN•CHAGO🚀'
global.numberowner = '6289531035137'
global.mail = 'sanjaya28051@gmail.vom' 
global.gc = 'https://whatsapp.com/channel/0029Vb652o9G3R3dlONb700V'
global.instagram = 'https://instagram.com/'
global.wm = '© DRN•CHAGO'
global.wait = '_*Sabar Ya Sayangku Lagi Di Proses...*_'
global.eror = '_*Servernya Ngambek Nihh Lapor Owner Dong*_'
global.stiker_wait = '*⫹⫺ Sticker lagi dibikin jadi.. Sabar Ya Sayangkuu...*'
global.packname = 'Dibuat Oleh'
global.author = 'BOT DRN by DRN•CHAGO'
global.maxwarn = '7' // Peringatan maksimum
global.antiporn = true // Auto delete pesan porno (bot harus admin)

global.lann = 'REALKIY' 

global.btc = 'YOUR_APIKEY_HERE'


global.APIs = {   
  lann: 'https://api.betabotz.eu.org',
  btc: 'https://api.botcahx.eu.org'
}
global.APIKeys = { 
  'https://api.betabotz.eu.org': global.lann, 
  'https://api.botcahx.eu.org': global.btc //BEBAS MAU ISI ATAU GAK
}

let fs = require('fs')
let chalk = require('chalk')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  delete require.cache[file]
  require(file)
})
